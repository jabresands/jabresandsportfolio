from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.common.exceptions import ElementClickInterceptedException
import time

CHROME_DRIVER_PATH = "Desktop/chromedriver"
SIMILAR_ACCOUNT = "chefsteps"
EMAIL = ME_EMAIL
PASSWORD = MY_PASSWORD"
USERNAME = MY_USERNAME

class InstaFollower:

    def __init__(self):
        self.service = Service(CHROME_DRIVER_PATH)
        self.driver = webdriver.Chrome(service=self.service)
        self.driver.get("https://www.instagram.com/")

    def save_login_info_question(self):
        not_now = self.driver.find_element(By.XPATH, '//*[@id="react-root"]/section/main/div/div/div/div/button')
        not_now.click()

    def turn_on_notifications_question(self):
        not_now = self.driver.find_element(By.XPATH,
                                           '/html/body/div[1]/div/div/div/div[2]/div/div/div[1]/div/div[2]/div/div/div/div/div[2]/div/div/div[3]/button[2]')
        not_now.click()

    def login(self):
        time.sleep(5)
        user_id_field = self.driver.find_element(By.XPATH, '//*[@id="loginForm"]/div/div[1]/div/label/input')
        user_id_field.send_keys(USERNAME)

        password_field = self.driver.find_element(By.XPATH, '//*[@id="loginForm"]/div/div[2]/div/label/input')
        password_field.send_keys(PASSWORD)

        log_in_button = self.driver.find_element(By.XPATH, '//*[@id="loginForm"]/div/div[3]/button/div')
        log_in_button.click()

        time.sleep(5)
        self.save_login_info_question()

        time.sleep(10)
        self.turn_on_notifications_question()

    def find_followers(self):
        self.driver.get(f"https://www.instagram.com/{SIMILAR_ACCOUNT}")
        time.sleep(10)
        follower_link = self.driver.find_element(By.XPATH, '/html/body/div[1]/div/div/div/div[1]/div/div/div/div[1]/section/main/div/header/section/ul/li[2]/a/div')
        follower_link.click()

        time.sleep(5)

        scrollable_popup = self.driver.find_element(By.XPATH, '/html/body/div[1]/div/div/div/div[2]/div/div/div[1]/div/div[2]/div/div/div/div/div[2]/div/div/div[2]')
        for i in range(10):
            self.driver.execute_script("arguments[0].scrollTop = arguments[0].scrollHeight", scrollable_popup)
            time.sleep(2)

    def follow(self):
        all_buttons = self.driver.find_elements(By.XPATH, "//li[contains(@class, '_aaei')]//button[@class='_acan _acap _acas']")

        for button in all_buttons:
            try:
                button.click()
                time.sleep(1)
            except ElementClickInterceptedException:
                cancel_button = self.driver.find_element(By.XPATH, "//button[@class='_a9-- _a9_1']")
                cancel_button.click()


bot = InstaFollower()
bot.login()
bot.find_followers()
bot.follow()
