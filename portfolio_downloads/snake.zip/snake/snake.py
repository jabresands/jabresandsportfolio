from turtle import Turtle

STARTING_POSITIONS = [(0, 0), (-20, 0), (-40, 0)]   # This is called a constant. It's all caps.
MOVE_DISTANCE = 20    # Don't have to dig through body of code if we want to make changes
UP = 90
DOWN = 270
LEFT = 180
RIGHT = 0

class Snake:

    def __init__(self):

        self.segments = []
        self.create_snake()
        self.head = self.segments[0]

    def create_snake(self):
        for position in STARTING_POSITIONS:   # creates snake - high score
            self.add_segment(position)

    def add_segment(self, position):          # creates snake - high score
        new_segment = Turtle("square")
        new_segment.color("white")
        new_segment.penup()
        new_segment.goto(position)
        self.segments.append(new_segment)

    def extend(self):
        self.add_segment(self.segments[-1].position()) #position is method that comes from turtle class

    def move(self):

        for seg_num in range(len(self.segments) - 1, 0, -1):
            new_x = self.segments[seg_num - 1].xcor()  # get hold of 2nd to last segment's x coordinate
            new_y = self.segments[seg_num - 1].ycor()  # get hold of 2nd to last segment's y coordinate
            self.segments[seg_num].goto(new_x, new_y)  # tell last segment to go to position of 2nd to last segment
        self.head.forward(MOVE_DISTANCE)

    def up(self):
        if self.head.heading() != DOWN:
            self.head.setheading(UP)

    def down(self):
        if self.head.heading() != UP:
            self.head.setheading(DOWN)

    def left(self):
        if self.head.heading() != RIGHT:
            self.head.setheading(LEFT)

    def right(self):
        if self.head.heading() != LEFT:
            self.head.setheading(RIGHT)
