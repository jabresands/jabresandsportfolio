from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import time

TWITTER_EMAIL = MY_EMAIL
TWITTER_PASSWORD = MY_PASSWORD
TWITTER_USERNAME = MY_USERNAME
PROMISED_DOWN = 150
PROMISED_UP = 10
CHROME_DRIVER_PATH = Service(Development/chromedriver")


class InternetSpeedTwitterBot:

    def __init__(self):
        self.down_speed = 0
        self.up_speed = 0
        self.driver = webdriver.Chrome(service=CHROME_DRIVER_PATH)
        self.driver.get("https://www.speedtest.net/")

    def get_internet_speed(self):
        button = self.driver.find_element(By.XPATH, '//*[@id="container"]/div/div[3]/div/div/div/div[2]/div[3]/div[1]/a/span[4]')
        button.click()

        time.sleep(10)
        test_speed_down = self.driver.find_element(By.XPATH, '//*[@id="container"]/div/div[3]/div/div/div/div[2]/div[3]/div[3]/div/div[3]/div/div/div[2]/div[1]/div[1]/div/div[2]/span')
        time.sleep(10)
        self.down_speed = float(test_speed_down.text)
        print(f"Down: {self.down_speed}")

        time.sleep(10)
        test_speed_up = self.driver.find_element(By.XPATH, '//*[@id="container"]/div/div[3]/div/div/div/div[2]/div[3]/div[3]/div/div[3]/div/div/div[2]/div[1]/div[2]/div/div[2]/span')
        time.sleep(10)
        self.up_speed = float(test_speed_up.text)
        print(f"Up: {self.up_speed}")


    def unusual_activity(self):
        ####################Unusual Login Activity### Comment this out if no longer getting that prompt#################
        time.sleep(5)
        unusual_activity_field = self.driver.find_element(By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div[2]/label/div/div[2]/div/input')
        unusual_activity_field.send_keys(TWITTER_USERNAME)

        time.sleep(5)
        next_button = self.driver.find_element(By.XPATH, '//*[@id="layers"]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div/div/div/div/span/span')
        next_button.click()

        time.sleep(5)
        password_field = self.driver.find_element(By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div/div[3]/div/label/div/div[2]/div[1]/input')
        password_field.send_keys(TWITTER_PASSWORD)

        time.sleep(5)
        log_in_button = self.driver.find_element(By.XPATH, '//*[@id="layers"]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div[1]/div/div/div/div/span/span')
        log_in_button.click()

        ################################################################################################################

    def tweet_at_provider(self):

        time.sleep(10)
        tweet = self.driver.find_element(by="css selector", value='.public-DraftStyleDefault-block.public-DraftStyleDefault-ltr')
        tweet.send_keys(f"Hey Internet Provider, why is my internet speed {self.down_speed}down/{self.up_speed}up when I pay for 300down/50up?")
        # tweet.send_keys(f"Hey Internet Provider, why is my internet speed {self.test_speed_down}down/{self.test_speed_up}up when I pay for 300down/50up?")

        time.sleep(10)
        send_tweet = self.driver.find_element(By.XPATH, '/html/body/div[1]/div/div/div[2]/main/div/div/div/div[1]/div/div[2]/div/div[2]/div[1]/div/div/div/div[2]/div[3]/div/div/div[2]/div[3]/div/span/span')
        send_tweet.click()


    def log_into_twitter(self):
        self.driver.get("https://twitter.com/i/flow/login")

        time.sleep(5)
        email_field = self.driver.find_element(By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div/div/div[5]/label/div/div[2]/div/input')
        email_field.send_keys(TWITTER_EMAIL)

        time.sleep(5)
        sign_in = self.driver.find_element(By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div/div/div[6]/div')
        sign_in.click()

        time.sleep(4)

        try:
            password_field = self.driver.find_element(By.XPATH, '/html/body/div/div/div/div[1]/div/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[1]/div/div/div[3]/div/label/div/div[2]/div[1]/input')
            password_field.send_keys(TWITTER_PASSWORD)
            time.sleep(5)

            log_in_button = self.driver.find_element(By.XPATH, '/html/body/div/div/div/div[1]/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div[2]/div/div[1]/div/div/div/div/span/span')
            log_in_button.click()
        except:
            self.unusual_activity()

        time.sleep(10)
        self.tweet_at_provider()


# bot = InternetSpeedTwitterBot()
# bot.get_internet_speed()
# time.sleep(10)
# bot.log_into_twitter()