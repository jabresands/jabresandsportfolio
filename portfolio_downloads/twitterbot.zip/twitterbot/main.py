from InternetSpeedTwitterBot import InternetSpeedTwitterBot
import time

TWITTER_EMAIL = MY_EMAIL
TWITTER_PASSWORD = MY_PASSWORD

bot = InternetSpeedTwitterBot()

bot.get_internet_speed()

time.sleep(10)

bot.log_into_twitter()